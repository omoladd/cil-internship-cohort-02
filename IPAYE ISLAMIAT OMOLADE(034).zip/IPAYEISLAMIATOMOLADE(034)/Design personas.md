# PRIMARY PERSONA FOR A DELIVERY TRACKING APP
https://www.figma.com/file/5MVeX5K1SFDetBY3xrja1j/CIL-----Primary-Persona-%5BTemplate%5D?node-id=0%3A1

# SECOND PERSONA
https://www.figma.com/file/bGYjMgOeOFDjOqU8tBpr0U/CIL---Persona-2-%5BTemplate%5D?node-id=0%3A1