# Instagram Screens showing the Homepage,Signin Page and Profile Screen

https://www.figma.com/file/4zXHeRqG5h0IShDPaidosI/Instagram-Wireframe?node-id=0%3A1